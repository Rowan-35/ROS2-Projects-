from setuptools import find_packages, setup

package_name = 'fleet_coordination'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rowan',
    maintainer_email='rowan@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
   entry_points={
        'console_scripts': [
            'task_manager = fleet_coordination.task_manager:main',
            'vehicle_node = fleet_coordination.vehicle_node:main',
            'traffic_controller =fleet_coordination.traffic_controller:main',
            'monitor_node = fleet_coordination.monitor_node:main'
        ],
    },
)
