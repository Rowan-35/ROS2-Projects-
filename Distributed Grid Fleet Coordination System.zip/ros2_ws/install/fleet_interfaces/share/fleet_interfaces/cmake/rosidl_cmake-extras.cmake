# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(fleet_interfaces_IDL_FILES "msg/VehicleState.idl;srv/RequestTask.idl;srv/RequestMove.idl")
set(fleet_interfaces_INTERFACE_FILES "msg/VehicleState.msg;srv/RequestTask.srv;srv/RequestMove.srv")
