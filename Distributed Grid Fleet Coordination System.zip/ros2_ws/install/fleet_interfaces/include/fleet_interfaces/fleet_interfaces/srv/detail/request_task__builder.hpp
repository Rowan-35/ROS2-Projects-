// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from fleet_interfaces:srv/RequestTask.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_task.hpp"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__BUILDER_HPP_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "fleet_interfaces/srv/detail/request_task__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestTask_Request_vehicle_id
{
public:
  Init_RequestTask_Request_vehicle_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::fleet_interfaces::srv::RequestTask_Request vehicle_id(::fleet_interfaces::srv::RequestTask_Request::_vehicle_id_type arg)
  {
    msg_.vehicle_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestTask_Request>()
{
  return fleet_interfaces::srv::builder::Init_RequestTask_Request_vehicle_id();
}

}  // namespace fleet_interfaces


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestTask_Response_dropoff_y
{
public:
  explicit Init_RequestTask_Response_dropoff_y(::fleet_interfaces::srv::RequestTask_Response & msg)
  : msg_(msg)
  {}
  ::fleet_interfaces::srv::RequestTask_Response dropoff_y(::fleet_interfaces::srv::RequestTask_Response::_dropoff_y_type arg)
  {
    msg_.dropoff_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Response msg_;
};

class Init_RequestTask_Response_dropoff_x
{
public:
  explicit Init_RequestTask_Response_dropoff_x(::fleet_interfaces::srv::RequestTask_Response & msg)
  : msg_(msg)
  {}
  Init_RequestTask_Response_dropoff_y dropoff_x(::fleet_interfaces::srv::RequestTask_Response::_dropoff_x_type arg)
  {
    msg_.dropoff_x = std::move(arg);
    return Init_RequestTask_Response_dropoff_y(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Response msg_;
};

class Init_RequestTask_Response_pickup_y
{
public:
  explicit Init_RequestTask_Response_pickup_y(::fleet_interfaces::srv::RequestTask_Response & msg)
  : msg_(msg)
  {}
  Init_RequestTask_Response_dropoff_x pickup_y(::fleet_interfaces::srv::RequestTask_Response::_pickup_y_type arg)
  {
    msg_.pickup_y = std::move(arg);
    return Init_RequestTask_Response_dropoff_x(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Response msg_;
};

class Init_RequestTask_Response_pickup_x
{
public:
  explicit Init_RequestTask_Response_pickup_x(::fleet_interfaces::srv::RequestTask_Response & msg)
  : msg_(msg)
  {}
  Init_RequestTask_Response_pickup_y pickup_x(::fleet_interfaces::srv::RequestTask_Response::_pickup_x_type arg)
  {
    msg_.pickup_x = std::move(arg);
    return Init_RequestTask_Response_pickup_y(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Response msg_;
};

class Init_RequestTask_Response_success
{
public:
  Init_RequestTask_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RequestTask_Response_pickup_x success(::fleet_interfaces::srv::RequestTask_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_RequestTask_Response_pickup_x(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestTask_Response>()
{
  return fleet_interfaces::srv::builder::Init_RequestTask_Response_success();
}

}  // namespace fleet_interfaces


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestTask_Event_response
{
public:
  explicit Init_RequestTask_Event_response(::fleet_interfaces::srv::RequestTask_Event & msg)
  : msg_(msg)
  {}
  ::fleet_interfaces::srv::RequestTask_Event response(::fleet_interfaces::srv::RequestTask_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Event msg_;
};

class Init_RequestTask_Event_request
{
public:
  explicit Init_RequestTask_Event_request(::fleet_interfaces::srv::RequestTask_Event & msg)
  : msg_(msg)
  {}
  Init_RequestTask_Event_response request(::fleet_interfaces::srv::RequestTask_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_RequestTask_Event_response(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Event msg_;
};

class Init_RequestTask_Event_info
{
public:
  Init_RequestTask_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RequestTask_Event_request info(::fleet_interfaces::srv::RequestTask_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_RequestTask_Event_request(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestTask_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestTask_Event>()
{
  return fleet_interfaces::srv::builder::Init_RequestTask_Event_info();
}

}  // namespace fleet_interfaces

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__BUILDER_HPP_
