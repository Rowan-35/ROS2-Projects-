// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from fleet_interfaces:srv/RequestMove.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_move.hpp"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_HPP_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Request __attribute__((deprecated))
#else
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Request __declspec(deprecated)
#endif

namespace fleet_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct RequestMove_Request_
{
  using Type = RequestMove_Request_<ContainerAllocator>;

  explicit RequestMove_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->vehicle_id = "";
      this->current_x = 0l;
      this->current_y = 0l;
      this->target_x = 0l;
      this->target_y = 0l;
    }
  }

  explicit RequestMove_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : vehicle_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->vehicle_id = "";
      this->current_x = 0l;
      this->current_y = 0l;
      this->target_x = 0l;
      this->target_y = 0l;
    }
  }

  // field types and members
  using _vehicle_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _vehicle_id_type vehicle_id;
  using _current_x_type =
    int32_t;
  _current_x_type current_x;
  using _current_y_type =
    int32_t;
  _current_y_type current_y;
  using _target_x_type =
    int32_t;
  _target_x_type target_x;
  using _target_y_type =
    int32_t;
  _target_y_type target_y;

  // setters for named parameter idiom
  Type & set__vehicle_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->vehicle_id = _arg;
    return *this;
  }
  Type & set__current_x(
    const int32_t & _arg)
  {
    this->current_x = _arg;
    return *this;
  }
  Type & set__current_y(
    const int32_t & _arg)
  {
    this->current_y = _arg;
    return *this;
  }
  Type & set__target_x(
    const int32_t & _arg)
  {
    this->target_x = _arg;
    return *this;
  }
  Type & set__target_y(
    const int32_t & _arg)
  {
    this->target_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Request
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Request
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RequestMove_Request_ & other) const
  {
    if (this->vehicle_id != other.vehicle_id) {
      return false;
    }
    if (this->current_x != other.current_x) {
      return false;
    }
    if (this->current_y != other.current_y) {
      return false;
    }
    if (this->target_x != other.target_x) {
      return false;
    }
    if (this->target_y != other.target_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const RequestMove_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RequestMove_Request_

// alias to use template instance with default allocator
using RequestMove_Request =
  fleet_interfaces::srv::RequestMove_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace fleet_interfaces


#ifndef _WIN32
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Response __attribute__((deprecated))
#else
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Response __declspec(deprecated)
#endif

namespace fleet_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct RequestMove_Response_
{
  using Type = RequestMove_Response_<ContainerAllocator>;

  explicit RequestMove_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->approved = false;
    }
  }

  explicit RequestMove_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->approved = false;
    }
  }

  // field types and members
  using _approved_type =
    bool;
  _approved_type approved;

  // setters for named parameter idiom
  Type & set__approved(
    const bool & _arg)
  {
    this->approved = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Response
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Response
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RequestMove_Response_ & other) const
  {
    if (this->approved != other.approved) {
      return false;
    }
    return true;
  }
  bool operator!=(const RequestMove_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RequestMove_Response_

// alias to use template instance with default allocator
using RequestMove_Response =
  fleet_interfaces::srv::RequestMove_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace fleet_interfaces


// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Event __attribute__((deprecated))
#else
# define DEPRECATED__fleet_interfaces__srv__RequestMove_Event __declspec(deprecated)
#endif

namespace fleet_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct RequestMove_Event_
{
  using Type = RequestMove_Event_<ContainerAllocator>;

  explicit RequestMove_Event_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit RequestMove_Event_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    service_msgs::msg::ServiceEventInfo_<ContainerAllocator>;
  _info_type info;
  using _request_type =
    rosidl_runtime_cpp::BoundedVector<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>>;
  _request_type request;
  using _response_type =
    rosidl_runtime_cpp::BoundedVector<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>>;
  _response_type response;

  // setters for named parameter idiom
  Type & set__info(
    const service_msgs::msg::ServiceEventInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }
  Type & set__request(
    const rosidl_runtime_cpp::BoundedVector<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<fleet_interfaces::srv::RequestMove_Request_<ContainerAllocator>>> & _arg)
  {
    this->request = _arg;
    return *this;
  }
  Type & set__response(
    const rosidl_runtime_cpp::BoundedVector<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<fleet_interfaces::srv::RequestMove_Response_<ContainerAllocator>>> & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> *;
  using ConstRawPtr =
    const fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Event
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__fleet_interfaces__srv__RequestMove_Event
    std::shared_ptr<fleet_interfaces::srv::RequestMove_Event_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RequestMove_Event_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    if (this->request != other.request) {
      return false;
    }
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const RequestMove_Event_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RequestMove_Event_

// alias to use template instance with default allocator
using RequestMove_Event =
  fleet_interfaces::srv::RequestMove_Event_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace fleet_interfaces

namespace fleet_interfaces
{

namespace srv
{

struct RequestMove
{
  using Request = fleet_interfaces::srv::RequestMove_Request;
  using Response = fleet_interfaces::srv::RequestMove_Response;
  using Event = fleet_interfaces::srv::RequestMove_Event;
};

}  // namespace srv

}  // namespace fleet_interfaces

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_HPP_
