// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from fleet_interfaces:srv/RequestMove.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_move.hpp"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__BUILDER_HPP_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "fleet_interfaces/srv/detail/request_move__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestMove_Request_target_y
{
public:
  explicit Init_RequestMove_Request_target_y(::fleet_interfaces::srv::RequestMove_Request & msg)
  : msg_(msg)
  {}
  ::fleet_interfaces::srv::RequestMove_Request target_y(::fleet_interfaces::srv::RequestMove_Request::_target_y_type arg)
  {
    msg_.target_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Request msg_;
};

class Init_RequestMove_Request_target_x
{
public:
  explicit Init_RequestMove_Request_target_x(::fleet_interfaces::srv::RequestMove_Request & msg)
  : msg_(msg)
  {}
  Init_RequestMove_Request_target_y target_x(::fleet_interfaces::srv::RequestMove_Request::_target_x_type arg)
  {
    msg_.target_x = std::move(arg);
    return Init_RequestMove_Request_target_y(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Request msg_;
};

class Init_RequestMove_Request_current_y
{
public:
  explicit Init_RequestMove_Request_current_y(::fleet_interfaces::srv::RequestMove_Request & msg)
  : msg_(msg)
  {}
  Init_RequestMove_Request_target_x current_y(::fleet_interfaces::srv::RequestMove_Request::_current_y_type arg)
  {
    msg_.current_y = std::move(arg);
    return Init_RequestMove_Request_target_x(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Request msg_;
};

class Init_RequestMove_Request_current_x
{
public:
  explicit Init_RequestMove_Request_current_x(::fleet_interfaces::srv::RequestMove_Request & msg)
  : msg_(msg)
  {}
  Init_RequestMove_Request_current_y current_x(::fleet_interfaces::srv::RequestMove_Request::_current_x_type arg)
  {
    msg_.current_x = std::move(arg);
    return Init_RequestMove_Request_current_y(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Request msg_;
};

class Init_RequestMove_Request_vehicle_id
{
public:
  Init_RequestMove_Request_vehicle_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RequestMove_Request_current_x vehicle_id(::fleet_interfaces::srv::RequestMove_Request::_vehicle_id_type arg)
  {
    msg_.vehicle_id = std::move(arg);
    return Init_RequestMove_Request_current_x(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestMove_Request>()
{
  return fleet_interfaces::srv::builder::Init_RequestMove_Request_vehicle_id();
}

}  // namespace fleet_interfaces


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestMove_Response_approved
{
public:
  Init_RequestMove_Response_approved()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::fleet_interfaces::srv::RequestMove_Response approved(::fleet_interfaces::srv::RequestMove_Response::_approved_type arg)
  {
    msg_.approved = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestMove_Response>()
{
  return fleet_interfaces::srv::builder::Init_RequestMove_Response_approved();
}

}  // namespace fleet_interfaces


namespace fleet_interfaces
{

namespace srv
{

namespace builder
{

class Init_RequestMove_Event_response
{
public:
  explicit Init_RequestMove_Event_response(::fleet_interfaces::srv::RequestMove_Event & msg)
  : msg_(msg)
  {}
  ::fleet_interfaces::srv::RequestMove_Event response(::fleet_interfaces::srv::RequestMove_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Event msg_;
};

class Init_RequestMove_Event_request
{
public:
  explicit Init_RequestMove_Event_request(::fleet_interfaces::srv::RequestMove_Event & msg)
  : msg_(msg)
  {}
  Init_RequestMove_Event_response request(::fleet_interfaces::srv::RequestMove_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_RequestMove_Event_response(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Event msg_;
};

class Init_RequestMove_Event_info
{
public:
  Init_RequestMove_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RequestMove_Event_request info(::fleet_interfaces::srv::RequestMove_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_RequestMove_Event_request(msg_);
  }

private:
  ::fleet_interfaces::srv::RequestMove_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::srv::RequestMove_Event>()
{
  return fleet_interfaces::srv::builder::Init_RequestMove_Event_info();
}

}  // namespace fleet_interfaces

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__BUILDER_HPP_
