// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from fleet_interfaces:srv/RequestMove.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_move.h"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_H_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'vehicle_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/RequestMove in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestMove_Request
{
  rosidl_runtime_c__String vehicle_id;
  int32_t current_x;
  int32_t current_y;
  int32_t target_x;
  int32_t target_y;
} fleet_interfaces__srv__RequestMove_Request;

// Struct for a sequence of fleet_interfaces__srv__RequestMove_Request.
typedef struct fleet_interfaces__srv__RequestMove_Request__Sequence
{
  fleet_interfaces__srv__RequestMove_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestMove_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/RequestMove in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestMove_Response
{
  bool approved;
} fleet_interfaces__srv__RequestMove_Response;

// Struct for a sequence of fleet_interfaces__srv__RequestMove_Response.
typedef struct fleet_interfaces__srv__RequestMove_Response__Sequence
{
  fleet_interfaces__srv__RequestMove_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestMove_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  fleet_interfaces__srv__RequestMove_Event__request__MAX_SIZE = 1
};
// response
enum
{
  fleet_interfaces__srv__RequestMove_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/RequestMove in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestMove_Event
{
  service_msgs__msg__ServiceEventInfo info;
  fleet_interfaces__srv__RequestMove_Request__Sequence request;
  fleet_interfaces__srv__RequestMove_Response__Sequence response;
} fleet_interfaces__srv__RequestMove_Event;

// Struct for a sequence of fleet_interfaces__srv__RequestMove_Event.
typedef struct fleet_interfaces__srv__RequestMove_Event__Sequence
{
  fleet_interfaces__srv__RequestMove_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestMove_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_MOVE__STRUCT_H_
