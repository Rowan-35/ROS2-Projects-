// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from fleet_interfaces:srv/RequestMove.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "fleet_interfaces/srv/detail/request_move__rosidl_typesupport_introspection_c.h"
#include "fleet_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "fleet_interfaces/srv/detail/request_move__functions.h"
#include "fleet_interfaces/srv/detail/request_move__struct.h"


// Include directives for member types
// Member `vehicle_id`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  fleet_interfaces__srv__RequestMove_Request__init(message_memory);
}

void fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_fini_function(void * message_memory)
{
  fleet_interfaces__srv__RequestMove_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_member_array[5] = {
  {
    "vehicle_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Request, vehicle_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "current_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Request, current_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "current_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Request, current_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "target_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Request, target_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "target_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Request, target_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_members = {
  "fleet_interfaces__srv",  // message namespace
  "RequestMove_Request",  // message name
  5,  // number of fields
  sizeof(fleet_interfaces__srv__RequestMove_Request),
  false,  // has_any_key_member_
  fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_member_array,  // message members
  fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle = {
  0,
  &fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_members,
  get_message_typesupport_handle_function,
  &fleet_interfaces__srv__RequestMove_Request__get_type_hash,
  &fleet_interfaces__srv__RequestMove_Request__get_type_description,
  &fleet_interfaces__srv__RequestMove_Request__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Request)() {
  if (!fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle.typesupport_identifier) {
    fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "fleet_interfaces/srv/detail/request_move__rosidl_typesupport_introspection_c.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_move__functions.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_move__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  fleet_interfaces__srv__RequestMove_Response__init(message_memory);
}

void fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_fini_function(void * message_memory)
{
  fleet_interfaces__srv__RequestMove_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_member_array[1] = {
  {
    "approved",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Response, approved),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_members = {
  "fleet_interfaces__srv",  // message namespace
  "RequestMove_Response",  // message name
  1,  // number of fields
  sizeof(fleet_interfaces__srv__RequestMove_Response),
  false,  // has_any_key_member_
  fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_member_array,  // message members
  fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle = {
  0,
  &fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_members,
  get_message_typesupport_handle_function,
  &fleet_interfaces__srv__RequestMove_Response__get_type_hash,
  &fleet_interfaces__srv__RequestMove_Response__get_type_description,
  &fleet_interfaces__srv__RequestMove_Response__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Response)() {
  if (!fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle.typesupport_identifier) {
    fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "fleet_interfaces/srv/detail/request_move__rosidl_typesupport_introspection_c.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_move__functions.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_move__struct.h"


// Include directives for member types
// Member `info`
#include "service_msgs/msg/service_event_info.h"
// Member `info`
#include "service_msgs/msg/detail/service_event_info__rosidl_typesupport_introspection_c.h"
// Member `request`
// Member `response`
#include "fleet_interfaces/srv/request_move.h"
// Member `request`
// Member `response`
// already included above
// #include "fleet_interfaces/srv/detail/request_move__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  fleet_interfaces__srv__RequestMove_Event__init(message_memory);
}

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_fini_function(void * message_memory)
{
  fleet_interfaces__srv__RequestMove_Event__fini(message_memory);
}

size_t fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__size_function__RequestMove_Event__request(
  const void * untyped_member)
{
  const fleet_interfaces__srv__RequestMove_Request__Sequence * member =
    (const fleet_interfaces__srv__RequestMove_Request__Sequence *)(untyped_member);
  return member->size;
}

const void * fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__request(
  const void * untyped_member, size_t index)
{
  const fleet_interfaces__srv__RequestMove_Request__Sequence * member =
    (const fleet_interfaces__srv__RequestMove_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void * fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__request(
  void * untyped_member, size_t index)
{
  fleet_interfaces__srv__RequestMove_Request__Sequence * member =
    (fleet_interfaces__srv__RequestMove_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__fetch_function__RequestMove_Event__request(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const fleet_interfaces__srv__RequestMove_Request * item =
    ((const fleet_interfaces__srv__RequestMove_Request *)
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__request(untyped_member, index));
  fleet_interfaces__srv__RequestMove_Request * value =
    (fleet_interfaces__srv__RequestMove_Request *)(untyped_value);
  *value = *item;
}

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__assign_function__RequestMove_Event__request(
  void * untyped_member, size_t index, const void * untyped_value)
{
  fleet_interfaces__srv__RequestMove_Request * item =
    ((fleet_interfaces__srv__RequestMove_Request *)
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__request(untyped_member, index));
  const fleet_interfaces__srv__RequestMove_Request * value =
    (const fleet_interfaces__srv__RequestMove_Request *)(untyped_value);
  *item = *value;
}

bool fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__resize_function__RequestMove_Event__request(
  void * untyped_member, size_t size)
{
  fleet_interfaces__srv__RequestMove_Request__Sequence * member =
    (fleet_interfaces__srv__RequestMove_Request__Sequence *)(untyped_member);
  fleet_interfaces__srv__RequestMove_Request__Sequence__fini(member);
  return fleet_interfaces__srv__RequestMove_Request__Sequence__init(member, size);
}

size_t fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__size_function__RequestMove_Event__response(
  const void * untyped_member)
{
  const fleet_interfaces__srv__RequestMove_Response__Sequence * member =
    (const fleet_interfaces__srv__RequestMove_Response__Sequence *)(untyped_member);
  return member->size;
}

const void * fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__response(
  const void * untyped_member, size_t index)
{
  const fleet_interfaces__srv__RequestMove_Response__Sequence * member =
    (const fleet_interfaces__srv__RequestMove_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void * fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__response(
  void * untyped_member, size_t index)
{
  fleet_interfaces__srv__RequestMove_Response__Sequence * member =
    (fleet_interfaces__srv__RequestMove_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__fetch_function__RequestMove_Event__response(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const fleet_interfaces__srv__RequestMove_Response * item =
    ((const fleet_interfaces__srv__RequestMove_Response *)
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__response(untyped_member, index));
  fleet_interfaces__srv__RequestMove_Response * value =
    (fleet_interfaces__srv__RequestMove_Response *)(untyped_value);
  *value = *item;
}

void fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__assign_function__RequestMove_Event__response(
  void * untyped_member, size_t index, const void * untyped_value)
{
  fleet_interfaces__srv__RequestMove_Response * item =
    ((fleet_interfaces__srv__RequestMove_Response *)
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__response(untyped_member, index));
  const fleet_interfaces__srv__RequestMove_Response * value =
    (const fleet_interfaces__srv__RequestMove_Response *)(untyped_value);
  *item = *value;
}

bool fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__resize_function__RequestMove_Event__response(
  void * untyped_member, size_t size)
{
  fleet_interfaces__srv__RequestMove_Response__Sequence * member =
    (fleet_interfaces__srv__RequestMove_Response__Sequence *)(untyped_member);
  fleet_interfaces__srv__RequestMove_Response__Sequence__fini(member);
  return fleet_interfaces__srv__RequestMove_Response__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_member_array[3] = {
  {
    "info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Event, info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "request",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Event, request),  // bytes offset in struct
    NULL,  // default value
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__size_function__RequestMove_Event__request,  // size() function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__request,  // get_const(index) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__request,  // get(index) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__fetch_function__RequestMove_Event__request,  // fetch(index, &value) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__assign_function__RequestMove_Event__request,  // assign(index, value) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__resize_function__RequestMove_Event__request  // resize(index) function pointer
  },
  {
    "response",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(fleet_interfaces__srv__RequestMove_Event, response),  // bytes offset in struct
    NULL,  // default value
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__size_function__RequestMove_Event__response,  // size() function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_const_function__RequestMove_Event__response,  // get_const(index) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__get_function__RequestMove_Event__response,  // get(index) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__fetch_function__RequestMove_Event__response,  // fetch(index, &value) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__assign_function__RequestMove_Event__response,  // assign(index, value) function pointer
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__resize_function__RequestMove_Event__response  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_members = {
  "fleet_interfaces__srv",  // message namespace
  "RequestMove_Event",  // message name
  3,  // number of fields
  sizeof(fleet_interfaces__srv__RequestMove_Event),
  false,  // has_any_key_member_
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_member_array,  // message members
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_init_function,  // function to initialize message memory (memory has to be allocated)
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_type_support_handle = {
  0,
  &fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_members,
  get_message_typesupport_handle_function,
  &fleet_interfaces__srv__RequestMove_Event__get_type_hash,
  &fleet_interfaces__srv__RequestMove_Event__get_type_description,
  &fleet_interfaces__srv__RequestMove_Event__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Event)() {
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, service_msgs, msg, ServiceEventInfo)();
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Request)();
  fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Response)();
  if (!fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_type_support_handle.typesupport_identifier) {
    fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_move__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_members = {
  "fleet_interfaces__srv",  // service namespace
  "RequestMove",  // service name
  // the following fields are initialized below on first access
  NULL,  // request message
  // fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle,
  NULL,  // response message
  // fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle
  NULL  // event_message
  // fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle
};


static rosidl_service_type_support_t fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_type_support_handle = {
  0,
  &fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_members,
  get_service_typesupport_handle_function,
  &fleet_interfaces__srv__RequestMove_Request__rosidl_typesupport_introspection_c__RequestMove_Request_message_type_support_handle,
  &fleet_interfaces__srv__RequestMove_Response__rosidl_typesupport_introspection_c__RequestMove_Response_message_type_support_handle,
  &fleet_interfaces__srv__RequestMove_Event__rosidl_typesupport_introspection_c__RequestMove_Event_message_type_support_handle,
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_CREATE_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    fleet_interfaces,
    srv,
    RequestMove
  ),
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_DESTROY_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    fleet_interfaces,
    srv,
    RequestMove
  ),
  &fleet_interfaces__srv__RequestMove__get_type_hash,
  &fleet_interfaces__srv__RequestMove__get_type_description,
  &fleet_interfaces__srv__RequestMove__get_type_description_sources,
};

// Forward declaration of message type support functions for service members
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Request)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Response)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Event)(void);

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_fleet_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove)(void) {
  if (!fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_type_support_handle.typesupport_identifier) {
    fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Response)()->data;
  }
  if (!service_members->event_members_) {
    service_members->event_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, fleet_interfaces, srv, RequestMove_Event)()->data;
  }

  return &fleet_interfaces__srv__detail__request_move__rosidl_typesupport_introspection_c__RequestMove_service_type_support_handle;
}
