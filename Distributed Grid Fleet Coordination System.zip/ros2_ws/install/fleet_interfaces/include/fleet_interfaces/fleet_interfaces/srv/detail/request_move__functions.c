// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from fleet_interfaces:srv/RequestMove.idl
// generated code does not contain a copyright notice
#include "fleet_interfaces/srv/detail/request_move__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `vehicle_id`
#include "rosidl_runtime_c/string_functions.h"

bool
fleet_interfaces__srv__RequestMove_Request__init(fleet_interfaces__srv__RequestMove_Request * msg)
{
  if (!msg) {
    return false;
  }
  // vehicle_id
  if (!rosidl_runtime_c__String__init(&msg->vehicle_id)) {
    fleet_interfaces__srv__RequestMove_Request__fini(msg);
    return false;
  }
  // current_x
  // current_y
  // target_x
  // target_y
  return true;
}

void
fleet_interfaces__srv__RequestMove_Request__fini(fleet_interfaces__srv__RequestMove_Request * msg)
{
  if (!msg) {
    return;
  }
  // vehicle_id
  rosidl_runtime_c__String__fini(&msg->vehicle_id);
  // current_x
  // current_y
  // target_x
  // target_y
}

bool
fleet_interfaces__srv__RequestMove_Request__are_equal(const fleet_interfaces__srv__RequestMove_Request * lhs, const fleet_interfaces__srv__RequestMove_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // vehicle_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->vehicle_id), &(rhs->vehicle_id)))
  {
    return false;
  }
  // current_x
  if (lhs->current_x != rhs->current_x) {
    return false;
  }
  // current_y
  if (lhs->current_y != rhs->current_y) {
    return false;
  }
  // target_x
  if (lhs->target_x != rhs->target_x) {
    return false;
  }
  // target_y
  if (lhs->target_y != rhs->target_y) {
    return false;
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Request__copy(
  const fleet_interfaces__srv__RequestMove_Request * input,
  fleet_interfaces__srv__RequestMove_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // vehicle_id
  if (!rosidl_runtime_c__String__copy(
      &(input->vehicle_id), &(output->vehicle_id)))
  {
    return false;
  }
  // current_x
  output->current_x = input->current_x;
  // current_y
  output->current_y = input->current_y;
  // target_x
  output->target_x = input->target_x;
  // target_y
  output->target_y = input->target_y;
  return true;
}

fleet_interfaces__srv__RequestMove_Request *
fleet_interfaces__srv__RequestMove_Request__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Request * msg = (fleet_interfaces__srv__RequestMove_Request *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(fleet_interfaces__srv__RequestMove_Request));
  bool success = fleet_interfaces__srv__RequestMove_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
fleet_interfaces__srv__RequestMove_Request__destroy(fleet_interfaces__srv__RequestMove_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    fleet_interfaces__srv__RequestMove_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
fleet_interfaces__srv__RequestMove_Request__Sequence__init(fleet_interfaces__srv__RequestMove_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Request * data = NULL;

  if (size) {
    data = (fleet_interfaces__srv__RequestMove_Request *)allocator.zero_allocate(size, sizeof(fleet_interfaces__srv__RequestMove_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = fleet_interfaces__srv__RequestMove_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        fleet_interfaces__srv__RequestMove_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
fleet_interfaces__srv__RequestMove_Request__Sequence__fini(fleet_interfaces__srv__RequestMove_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      fleet_interfaces__srv__RequestMove_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

fleet_interfaces__srv__RequestMove_Request__Sequence *
fleet_interfaces__srv__RequestMove_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Request__Sequence * array = (fleet_interfaces__srv__RequestMove_Request__Sequence *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = fleet_interfaces__srv__RequestMove_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
fleet_interfaces__srv__RequestMove_Request__Sequence__destroy(fleet_interfaces__srv__RequestMove_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    fleet_interfaces__srv__RequestMove_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
fleet_interfaces__srv__RequestMove_Request__Sequence__are_equal(const fleet_interfaces__srv__RequestMove_Request__Sequence * lhs, const fleet_interfaces__srv__RequestMove_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Request__Sequence__copy(
  const fleet_interfaces__srv__RequestMove_Request__Sequence * input,
  fleet_interfaces__srv__RequestMove_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(fleet_interfaces__srv__RequestMove_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    fleet_interfaces__srv__RequestMove_Request * data =
      (fleet_interfaces__srv__RequestMove_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!fleet_interfaces__srv__RequestMove_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          fleet_interfaces__srv__RequestMove_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


bool
fleet_interfaces__srv__RequestMove_Response__init(fleet_interfaces__srv__RequestMove_Response * msg)
{
  if (!msg) {
    return false;
  }
  // approved
  return true;
}

void
fleet_interfaces__srv__RequestMove_Response__fini(fleet_interfaces__srv__RequestMove_Response * msg)
{
  if (!msg) {
    return;
  }
  // approved
}

bool
fleet_interfaces__srv__RequestMove_Response__are_equal(const fleet_interfaces__srv__RequestMove_Response * lhs, const fleet_interfaces__srv__RequestMove_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // approved
  if (lhs->approved != rhs->approved) {
    return false;
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Response__copy(
  const fleet_interfaces__srv__RequestMove_Response * input,
  fleet_interfaces__srv__RequestMove_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // approved
  output->approved = input->approved;
  return true;
}

fleet_interfaces__srv__RequestMove_Response *
fleet_interfaces__srv__RequestMove_Response__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Response * msg = (fleet_interfaces__srv__RequestMove_Response *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(fleet_interfaces__srv__RequestMove_Response));
  bool success = fleet_interfaces__srv__RequestMove_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
fleet_interfaces__srv__RequestMove_Response__destroy(fleet_interfaces__srv__RequestMove_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    fleet_interfaces__srv__RequestMove_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
fleet_interfaces__srv__RequestMove_Response__Sequence__init(fleet_interfaces__srv__RequestMove_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Response * data = NULL;

  if (size) {
    data = (fleet_interfaces__srv__RequestMove_Response *)allocator.zero_allocate(size, sizeof(fleet_interfaces__srv__RequestMove_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = fleet_interfaces__srv__RequestMove_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        fleet_interfaces__srv__RequestMove_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
fleet_interfaces__srv__RequestMove_Response__Sequence__fini(fleet_interfaces__srv__RequestMove_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      fleet_interfaces__srv__RequestMove_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

fleet_interfaces__srv__RequestMove_Response__Sequence *
fleet_interfaces__srv__RequestMove_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Response__Sequence * array = (fleet_interfaces__srv__RequestMove_Response__Sequence *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = fleet_interfaces__srv__RequestMove_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
fleet_interfaces__srv__RequestMove_Response__Sequence__destroy(fleet_interfaces__srv__RequestMove_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    fleet_interfaces__srv__RequestMove_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
fleet_interfaces__srv__RequestMove_Response__Sequence__are_equal(const fleet_interfaces__srv__RequestMove_Response__Sequence * lhs, const fleet_interfaces__srv__RequestMove_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Response__Sequence__copy(
  const fleet_interfaces__srv__RequestMove_Response__Sequence * input,
  fleet_interfaces__srv__RequestMove_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(fleet_interfaces__srv__RequestMove_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    fleet_interfaces__srv__RequestMove_Response * data =
      (fleet_interfaces__srv__RequestMove_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!fleet_interfaces__srv__RequestMove_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          fleet_interfaces__srv__RequestMove_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `info`
#include "service_msgs/msg/detail/service_event_info__functions.h"
// Member `request`
// Member `response`
// already included above
// #include "fleet_interfaces/srv/detail/request_move__functions.h"

bool
fleet_interfaces__srv__RequestMove_Event__init(fleet_interfaces__srv__RequestMove_Event * msg)
{
  if (!msg) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__init(&msg->info)) {
    fleet_interfaces__srv__RequestMove_Event__fini(msg);
    return false;
  }
  // request
  if (!fleet_interfaces__srv__RequestMove_Request__Sequence__init(&msg->request, 0)) {
    fleet_interfaces__srv__RequestMove_Event__fini(msg);
    return false;
  }
  // response
  if (!fleet_interfaces__srv__RequestMove_Response__Sequence__init(&msg->response, 0)) {
    fleet_interfaces__srv__RequestMove_Event__fini(msg);
    return false;
  }
  return true;
}

void
fleet_interfaces__srv__RequestMove_Event__fini(fleet_interfaces__srv__RequestMove_Event * msg)
{
  if (!msg) {
    return;
  }
  // info
  service_msgs__msg__ServiceEventInfo__fini(&msg->info);
  // request
  fleet_interfaces__srv__RequestMove_Request__Sequence__fini(&msg->request);
  // response
  fleet_interfaces__srv__RequestMove_Response__Sequence__fini(&msg->response);
}

bool
fleet_interfaces__srv__RequestMove_Event__are_equal(const fleet_interfaces__srv__RequestMove_Event * lhs, const fleet_interfaces__srv__RequestMove_Event * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // request
  if (!fleet_interfaces__srv__RequestMove_Request__Sequence__are_equal(
      &(lhs->request), &(rhs->request)))
  {
    return false;
  }
  // response
  if (!fleet_interfaces__srv__RequestMove_Response__Sequence__are_equal(
      &(lhs->response), &(rhs->response)))
  {
    return false;
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Event__copy(
  const fleet_interfaces__srv__RequestMove_Event * input,
  fleet_interfaces__srv__RequestMove_Event * output)
{
  if (!input || !output) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // request
  if (!fleet_interfaces__srv__RequestMove_Request__Sequence__copy(
      &(input->request), &(output->request)))
  {
    return false;
  }
  // response
  if (!fleet_interfaces__srv__RequestMove_Response__Sequence__copy(
      &(input->response), &(output->response)))
  {
    return false;
  }
  return true;
}

fleet_interfaces__srv__RequestMove_Event *
fleet_interfaces__srv__RequestMove_Event__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Event * msg = (fleet_interfaces__srv__RequestMove_Event *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Event), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(fleet_interfaces__srv__RequestMove_Event));
  bool success = fleet_interfaces__srv__RequestMove_Event__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
fleet_interfaces__srv__RequestMove_Event__destroy(fleet_interfaces__srv__RequestMove_Event * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    fleet_interfaces__srv__RequestMove_Event__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
fleet_interfaces__srv__RequestMove_Event__Sequence__init(fleet_interfaces__srv__RequestMove_Event__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Event * data = NULL;

  if (size) {
    data = (fleet_interfaces__srv__RequestMove_Event *)allocator.zero_allocate(size, sizeof(fleet_interfaces__srv__RequestMove_Event), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = fleet_interfaces__srv__RequestMove_Event__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        fleet_interfaces__srv__RequestMove_Event__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
fleet_interfaces__srv__RequestMove_Event__Sequence__fini(fleet_interfaces__srv__RequestMove_Event__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      fleet_interfaces__srv__RequestMove_Event__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

fleet_interfaces__srv__RequestMove_Event__Sequence *
fleet_interfaces__srv__RequestMove_Event__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  fleet_interfaces__srv__RequestMove_Event__Sequence * array = (fleet_interfaces__srv__RequestMove_Event__Sequence *)allocator.allocate(sizeof(fleet_interfaces__srv__RequestMove_Event__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = fleet_interfaces__srv__RequestMove_Event__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
fleet_interfaces__srv__RequestMove_Event__Sequence__destroy(fleet_interfaces__srv__RequestMove_Event__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    fleet_interfaces__srv__RequestMove_Event__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
fleet_interfaces__srv__RequestMove_Event__Sequence__are_equal(const fleet_interfaces__srv__RequestMove_Event__Sequence * lhs, const fleet_interfaces__srv__RequestMove_Event__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Event__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
fleet_interfaces__srv__RequestMove_Event__Sequence__copy(
  const fleet_interfaces__srv__RequestMove_Event__Sequence * input,
  fleet_interfaces__srv__RequestMove_Event__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(fleet_interfaces__srv__RequestMove_Event);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    fleet_interfaces__srv__RequestMove_Event * data =
      (fleet_interfaces__srv__RequestMove_Event *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!fleet_interfaces__srv__RequestMove_Event__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          fleet_interfaces__srv__RequestMove_Event__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!fleet_interfaces__srv__RequestMove_Event__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
