// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from fleet_interfaces:srv/RequestTask.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_task.h"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__STRUCT_H_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'vehicle_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/RequestTask in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestTask_Request
{
  rosidl_runtime_c__String vehicle_id;
} fleet_interfaces__srv__RequestTask_Request;

// Struct for a sequence of fleet_interfaces__srv__RequestTask_Request.
typedef struct fleet_interfaces__srv__RequestTask_Request__Sequence
{
  fleet_interfaces__srv__RequestTask_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestTask_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/RequestTask in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestTask_Response
{
  bool success;
  int32_t pickup_x;
  int32_t pickup_y;
  int32_t dropoff_x;
  int32_t dropoff_y;
} fleet_interfaces__srv__RequestTask_Response;

// Struct for a sequence of fleet_interfaces__srv__RequestTask_Response.
typedef struct fleet_interfaces__srv__RequestTask_Response__Sequence
{
  fleet_interfaces__srv__RequestTask_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestTask_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  fleet_interfaces__srv__RequestTask_Event__request__MAX_SIZE = 1
};
// response
enum
{
  fleet_interfaces__srv__RequestTask_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/RequestTask in the package fleet_interfaces.
typedef struct fleet_interfaces__srv__RequestTask_Event
{
  service_msgs__msg__ServiceEventInfo info;
  fleet_interfaces__srv__RequestTask_Request__Sequence request;
  fleet_interfaces__srv__RequestTask_Response__Sequence response;
} fleet_interfaces__srv__RequestTask_Event;

// Struct for a sequence of fleet_interfaces__srv__RequestTask_Event.
typedef struct fleet_interfaces__srv__RequestTask_Event__Sequence
{
  fleet_interfaces__srv__RequestTask_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} fleet_interfaces__srv__RequestTask_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__STRUCT_H_
