// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from fleet_interfaces:srv/RequestTask.idl
// generated code does not contain a copyright notice
#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "fleet_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "fleet_interfaces/srv/detail/request_task__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_fleet_interfaces__srv__RequestTask_Request(
  const fleet_interfaces__srv__RequestTask_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_deserialize_fleet_interfaces__srv__RequestTask_Request(
  eprosima::fastcdr::Cdr &,
  fleet_interfaces__srv__RequestTask_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_fleet_interfaces__srv__RequestTask_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_fleet_interfaces__srv__RequestTask_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_key_fleet_interfaces__srv__RequestTask_Request(
  const fleet_interfaces__srv__RequestTask_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_key_fleet_interfaces__srv__RequestTask_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_key_fleet_interfaces__srv__RequestTask_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, fleet_interfaces, srv, RequestTask_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_task__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_fleet_interfaces__srv__RequestTask_Response(
  const fleet_interfaces__srv__RequestTask_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_deserialize_fleet_interfaces__srv__RequestTask_Response(
  eprosima::fastcdr::Cdr &,
  fleet_interfaces__srv__RequestTask_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_fleet_interfaces__srv__RequestTask_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_fleet_interfaces__srv__RequestTask_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_key_fleet_interfaces__srv__RequestTask_Response(
  const fleet_interfaces__srv__RequestTask_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_key_fleet_interfaces__srv__RequestTask_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_key_fleet_interfaces__srv__RequestTask_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, fleet_interfaces, srv, RequestTask_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "fleet_interfaces/srv/detail/request_task__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_fleet_interfaces__srv__RequestTask_Event(
  const fleet_interfaces__srv__RequestTask_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_deserialize_fleet_interfaces__srv__RequestTask_Event(
  eprosima::fastcdr::Cdr &,
  fleet_interfaces__srv__RequestTask_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_fleet_interfaces__srv__RequestTask_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_fleet_interfaces__srv__RequestTask_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
bool cdr_serialize_key_fleet_interfaces__srv__RequestTask_Event(
  const fleet_interfaces__srv__RequestTask_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t get_serialized_size_key_fleet_interfaces__srv__RequestTask_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
size_t max_serialized_size_key_fleet_interfaces__srv__RequestTask_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, fleet_interfaces, srv, RequestTask_Event)();

#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "fleet_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_fleet_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, fleet_interfaces, srv, RequestTask)();

#ifdef __cplusplus
}
#endif

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
