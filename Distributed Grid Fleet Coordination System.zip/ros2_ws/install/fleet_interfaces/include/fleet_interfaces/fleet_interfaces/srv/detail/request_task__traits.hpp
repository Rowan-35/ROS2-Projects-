// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from fleet_interfaces:srv/RequestTask.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/srv/request_task.hpp"


#ifndef FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__TRAITS_HPP_
#define FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "fleet_interfaces/srv/detail/request_task__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace fleet_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const RequestTask_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: vehicle_id
  {
    out << "vehicle_id: ";
    rosidl_generator_traits::value_to_yaml(msg.vehicle_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RequestTask_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: vehicle_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehicle_id: ";
    rosidl_generator_traits::value_to_yaml(msg.vehicle_id, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RequestTask_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace fleet_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use fleet_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const fleet_interfaces::srv::RequestTask_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  fleet_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use fleet_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const fleet_interfaces::srv::RequestTask_Request & msg)
{
  return fleet_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<fleet_interfaces::srv::RequestTask_Request>()
{
  return "fleet_interfaces::srv::RequestTask_Request";
}

template<>
inline const char * name<fleet_interfaces::srv::RequestTask_Request>()
{
  return "fleet_interfaces/srv/RequestTask_Request";
}

template<>
struct has_fixed_size<fleet_interfaces::srv::RequestTask_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<fleet_interfaces::srv::RequestTask_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<fleet_interfaces::srv::RequestTask_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace fleet_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const RequestTask_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: pickup_x
  {
    out << "pickup_x: ";
    rosidl_generator_traits::value_to_yaml(msg.pickup_x, out);
    out << ", ";
  }

  // member: pickup_y
  {
    out << "pickup_y: ";
    rosidl_generator_traits::value_to_yaml(msg.pickup_y, out);
    out << ", ";
  }

  // member: dropoff_x
  {
    out << "dropoff_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dropoff_x, out);
    out << ", ";
  }

  // member: dropoff_y
  {
    out << "dropoff_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dropoff_y, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RequestTask_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: pickup_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pickup_x: ";
    rosidl_generator_traits::value_to_yaml(msg.pickup_x, out);
    out << "\n";
  }

  // member: pickup_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pickup_y: ";
    rosidl_generator_traits::value_to_yaml(msg.pickup_y, out);
    out << "\n";
  }

  // member: dropoff_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dropoff_x: ";
    rosidl_generator_traits::value_to_yaml(msg.dropoff_x, out);
    out << "\n";
  }

  // member: dropoff_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dropoff_y: ";
    rosidl_generator_traits::value_to_yaml(msg.dropoff_y, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RequestTask_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace fleet_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use fleet_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const fleet_interfaces::srv::RequestTask_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  fleet_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use fleet_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const fleet_interfaces::srv::RequestTask_Response & msg)
{
  return fleet_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<fleet_interfaces::srv::RequestTask_Response>()
{
  return "fleet_interfaces::srv::RequestTask_Response";
}

template<>
inline const char * name<fleet_interfaces::srv::RequestTask_Response>()
{
  return "fleet_interfaces/srv/RequestTask_Response";
}

template<>
struct has_fixed_size<fleet_interfaces::srv::RequestTask_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<fleet_interfaces::srv::RequestTask_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<fleet_interfaces::srv::RequestTask_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__traits.hpp"

namespace fleet_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const RequestTask_Event & msg,
  std::ostream & out)
{
  out << "{";
  // member: info
  {
    out << "info: ";
    to_flow_style_yaml(msg.info, out);
    out << ", ";
  }

  // member: request
  {
    if (msg.request.size() == 0) {
      out << "request: []";
    } else {
      out << "request: [";
      size_t pending_items = msg.request.size();
      for (auto item : msg.request) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: response
  {
    if (msg.response.size() == 0) {
      out << "response: []";
    } else {
      out << "response: [";
      size_t pending_items = msg.response.size();
      for (auto item : msg.response) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RequestTask_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "info:\n";
    to_block_style_yaml(msg.info, out, indentation + 2);
  }

  // member: request
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.request.size() == 0) {
      out << "request: []\n";
    } else {
      out << "request:\n";
      for (auto item : msg.request) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: response
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.response.size() == 0) {
      out << "response: []\n";
    } else {
      out << "response:\n";
      for (auto item : msg.response) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RequestTask_Event & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace fleet_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use fleet_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const fleet_interfaces::srv::RequestTask_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  fleet_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use fleet_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const fleet_interfaces::srv::RequestTask_Event & msg)
{
  return fleet_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<fleet_interfaces::srv::RequestTask_Event>()
{
  return "fleet_interfaces::srv::RequestTask_Event";
}

template<>
inline const char * name<fleet_interfaces::srv::RequestTask_Event>()
{
  return "fleet_interfaces/srv/RequestTask_Event";
}

template<>
struct has_fixed_size<fleet_interfaces::srv::RequestTask_Event>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<fleet_interfaces::srv::RequestTask_Event>
  : std::integral_constant<bool, has_bounded_size<fleet_interfaces::srv::RequestTask_Request>::value && has_bounded_size<fleet_interfaces::srv::RequestTask_Response>::value && has_bounded_size<service_msgs::msg::ServiceEventInfo>::value> {};

template<>
struct is_message<fleet_interfaces::srv::RequestTask_Event>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<fleet_interfaces::srv::RequestTask>()
{
  return "fleet_interfaces::srv::RequestTask";
}

template<>
inline const char * name<fleet_interfaces::srv::RequestTask>()
{
  return "fleet_interfaces/srv/RequestTask";
}

template<>
struct has_fixed_size<fleet_interfaces::srv::RequestTask>
  : std::integral_constant<
    bool,
    has_fixed_size<fleet_interfaces::srv::RequestTask_Request>::value &&
    has_fixed_size<fleet_interfaces::srv::RequestTask_Response>::value
  >
{
};

template<>
struct has_bounded_size<fleet_interfaces::srv::RequestTask>
  : std::integral_constant<
    bool,
    has_bounded_size<fleet_interfaces::srv::RequestTask_Request>::value &&
    has_bounded_size<fleet_interfaces::srv::RequestTask_Response>::value
  >
{
};

template<>
struct is_service<fleet_interfaces::srv::RequestTask>
  : std::true_type
{
};

template<>
struct is_service_request<fleet_interfaces::srv::RequestTask_Request>
  : std::true_type
{
};

template<>
struct is_service_response<fleet_interfaces::srv::RequestTask_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // FLEET_INTERFACES__SRV__DETAIL__REQUEST_TASK__TRAITS_HPP_
