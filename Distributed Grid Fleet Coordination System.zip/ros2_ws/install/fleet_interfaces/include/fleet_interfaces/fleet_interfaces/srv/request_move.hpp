// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FLEET_INTERFACES__SRV__REQUEST_MOVE_HPP_
#define FLEET_INTERFACES__SRV__REQUEST_MOVE_HPP_

#include "fleet_interfaces/srv/detail/request_move__struct.hpp"
#include "fleet_interfaces/srv/detail/request_move__builder.hpp"
#include "fleet_interfaces/srv/detail/request_move__traits.hpp"
#include "fleet_interfaces/srv/detail/request_move__type_support.hpp"

#endif  // FLEET_INTERFACES__SRV__REQUEST_MOVE_HPP_
