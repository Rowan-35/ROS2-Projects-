// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FLEET_INTERFACES__MSG__VEHICLE_STATE_HPP_
#define FLEET_INTERFACES__MSG__VEHICLE_STATE_HPP_

#include "fleet_interfaces/msg/detail/vehicle_state__struct.hpp"
#include "fleet_interfaces/msg/detail/vehicle_state__builder.hpp"
#include "fleet_interfaces/msg/detail/vehicle_state__traits.hpp"
#include "fleet_interfaces/msg/detail/vehicle_state__type_support.hpp"

#endif  // FLEET_INTERFACES__MSG__VEHICLE_STATE_HPP_
