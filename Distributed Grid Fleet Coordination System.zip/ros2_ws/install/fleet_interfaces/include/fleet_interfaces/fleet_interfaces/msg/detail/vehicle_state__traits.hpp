// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from fleet_interfaces:msg/VehicleState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/msg/vehicle_state.hpp"


#ifndef FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__TRAITS_HPP_
#define FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "fleet_interfaces/msg/detail/vehicle_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace fleet_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const VehicleState & msg,
  std::ostream & out)
{
  out << "{";
  // member: vehicle_id
  {
    out << "vehicle_id: ";
    rosidl_generator_traits::value_to_yaml(msg.vehicle_id, out);
    out << ", ";
  }

  // member: current_state
  {
    out << "current_state: ";
    rosidl_generator_traits::value_to_yaml(msg.current_state, out);
    out << ", ";
  }

  // member: x
  {
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << ", ";
  }

  // member: y
  {
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const VehicleState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: vehicle_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehicle_id: ";
    rosidl_generator_traits::value_to_yaml(msg.vehicle_id, out);
    out << "\n";
  }

  // member: current_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_state: ";
    rosidl_generator_traits::value_to_yaml(msg.current_state, out);
    out << "\n";
  }

  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x: ";
    rosidl_generator_traits::value_to_yaml(msg.x, out);
    out << "\n";
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y: ";
    rosidl_generator_traits::value_to_yaml(msg.y, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const VehicleState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace fleet_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use fleet_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const fleet_interfaces::msg::VehicleState & msg,
  std::ostream & out, size_t indentation = 0)
{
  fleet_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use fleet_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const fleet_interfaces::msg::VehicleState & msg)
{
  return fleet_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<fleet_interfaces::msg::VehicleState>()
{
  return "fleet_interfaces::msg::VehicleState";
}

template<>
inline const char * name<fleet_interfaces::msg::VehicleState>()
{
  return "fleet_interfaces/msg/VehicleState";
}

template<>
struct has_fixed_size<fleet_interfaces::msg::VehicleState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<fleet_interfaces::msg::VehicleState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<fleet_interfaces::msg::VehicleState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__TRAITS_HPP_
