// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from fleet_interfaces:msg/VehicleState.idl
// generated code does not contain a copyright notice

#include "fleet_interfaces/msg/detail/vehicle_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_fleet_interfaces
const rosidl_type_hash_t *
fleet_interfaces__msg__VehicleState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xdd, 0x65, 0x27, 0x8d, 0x64, 0x6f, 0x20, 0xca,
      0x29, 0x4f, 0xd6, 0x23, 0x50, 0xa1, 0xfd, 0x59,
      0x54, 0x3a, 0x90, 0x38, 0xb4, 0x6c, 0x02, 0xcb,
      0xe0, 0xc2, 0x0b, 0x91, 0x06, 0x49, 0xb5, 0xcc,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char fleet_interfaces__msg__VehicleState__TYPE_NAME[] = "fleet_interfaces/msg/VehicleState";

// Define type names, field names, and default values
static char fleet_interfaces__msg__VehicleState__FIELD_NAME__vehicle_id[] = "vehicle_id";
static char fleet_interfaces__msg__VehicleState__FIELD_NAME__current_state[] = "current_state";
static char fleet_interfaces__msg__VehicleState__FIELD_NAME__x[] = "x";
static char fleet_interfaces__msg__VehicleState__FIELD_NAME__y[] = "y";

static rosidl_runtime_c__type_description__Field fleet_interfaces__msg__VehicleState__FIELDS[] = {
  {
    {fleet_interfaces__msg__VehicleState__FIELD_NAME__vehicle_id, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {fleet_interfaces__msg__VehicleState__FIELD_NAME__current_state, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {fleet_interfaces__msg__VehicleState__FIELD_NAME__x, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {fleet_interfaces__msg__VehicleState__FIELD_NAME__y, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
fleet_interfaces__msg__VehicleState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {fleet_interfaces__msg__VehicleState__TYPE_NAME, 33, 33},
      {fleet_interfaces__msg__VehicleState__FIELDS, 4, 4},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string vehicle_id\n"
  "string current_state\n"
  "int32 x\n"
  "int32 y";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
fleet_interfaces__msg__VehicleState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {fleet_interfaces__msg__VehicleState__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 55, 55},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
fleet_interfaces__msg__VehicleState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *fleet_interfaces__msg__VehicleState__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
