// generated from rosidl_generator_c/resource/idl.h.em
// with input from fleet_interfaces:msg/VehicleState.idl
// generated code does not contain a copyright notice

#ifndef FLEET_INTERFACES__MSG__VEHICLE_STATE_H_
#define FLEET_INTERFACES__MSG__VEHICLE_STATE_H_

#include "fleet_interfaces/msg/detail/vehicle_state__struct.h"
#include "fleet_interfaces/msg/detail/vehicle_state__functions.h"
#include "fleet_interfaces/msg/detail/vehicle_state__type_support.h"

#endif  // FLEET_INTERFACES__MSG__VEHICLE_STATE_H_
