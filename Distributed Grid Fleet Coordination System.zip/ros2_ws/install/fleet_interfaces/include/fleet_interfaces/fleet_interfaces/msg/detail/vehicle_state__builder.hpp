// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from fleet_interfaces:msg/VehicleState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "fleet_interfaces/msg/vehicle_state.hpp"


#ifndef FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__BUILDER_HPP_
#define FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "fleet_interfaces/msg/detail/vehicle_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace fleet_interfaces
{

namespace msg
{

namespace builder
{

class Init_VehicleState_y
{
public:
  explicit Init_VehicleState_y(::fleet_interfaces::msg::VehicleState & msg)
  : msg_(msg)
  {}
  ::fleet_interfaces::msg::VehicleState y(::fleet_interfaces::msg::VehicleState::_y_type arg)
  {
    msg_.y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::fleet_interfaces::msg::VehicleState msg_;
};

class Init_VehicleState_x
{
public:
  explicit Init_VehicleState_x(::fleet_interfaces::msg::VehicleState & msg)
  : msg_(msg)
  {}
  Init_VehicleState_y x(::fleet_interfaces::msg::VehicleState::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_VehicleState_y(msg_);
  }

private:
  ::fleet_interfaces::msg::VehicleState msg_;
};

class Init_VehicleState_current_state
{
public:
  explicit Init_VehicleState_current_state(::fleet_interfaces::msg::VehicleState & msg)
  : msg_(msg)
  {}
  Init_VehicleState_x current_state(::fleet_interfaces::msg::VehicleState::_current_state_type arg)
  {
    msg_.current_state = std::move(arg);
    return Init_VehicleState_x(msg_);
  }

private:
  ::fleet_interfaces::msg::VehicleState msg_;
};

class Init_VehicleState_vehicle_id
{
public:
  Init_VehicleState_vehicle_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VehicleState_current_state vehicle_id(::fleet_interfaces::msg::VehicleState::_vehicle_id_type arg)
  {
    msg_.vehicle_id = std::move(arg);
    return Init_VehicleState_current_state(msg_);
  }

private:
  ::fleet_interfaces::msg::VehicleState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::fleet_interfaces::msg::VehicleState>()
{
  return fleet_interfaces::msg::builder::Init_VehicleState_vehicle_id();
}

}  // namespace fleet_interfaces

#endif  // FLEET_INTERFACES__MSG__DETAIL__VEHICLE_STATE__BUILDER_HPP_
